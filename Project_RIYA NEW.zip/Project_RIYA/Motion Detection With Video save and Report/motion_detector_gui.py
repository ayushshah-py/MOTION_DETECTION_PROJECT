import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image, ImageTk
import cv2
import numpy as np
import threading
import sys
import os
import time
from datetime import datetime
import subprocess
import wave
import pyaudio

ALARM_MESSAGE = "Motion Detected!"
MOTION_THRESHOLD_AREA = 5000
BACKGROUND_COLOR = '#0b0c10'
CONTAINER_COLOR = '#1f2833'
CARD_COLOR = '#2c3845'
NEON_BLUE = '#66fcf1'
GREEN = '#4CAF50'
RED = '#F44336'

RATE = 44100
CHUNK = 1024
FORMAT = pyaudio.paInt16
CHANNELS = 1

is_motion_detected = False
last_motion_time = 0
last_alarm_sound_time = 0
alarm_running = False
camera_thread_running = False
camera = None
motion_events = []
video_writer = None
recording_active = False
root = None

audio_frames = []
audio_stream = None
pyaudio_instance = None
audio_thread_running = False
temp_video_filename = ""
temp_audio_filename = ""
timestamp = ""

def play_alarm_thread():
    """Continuously plays an alarm sound while motion is detected."""
    global alarm_running
    alarm_running = True
    while alarm_running:
        if sys.platform == "win32":
            try:
                import winsound
                winsound.Beep(1000, 200)
            except Exception as e:
                print(f"Could not play sound on Windows: {e}")
        else:
            try:
                if sys.platform == "darwin":
                    os.system('say "Motion Detected" &')
                else:
                    os.system('echo -e "\a"')
            except Exception as e:
                print(f"Could not play system sound: {e}")
        
        if time.time() - last_motion_time > 1 or not camera_thread_running:
            alarm_running = False

def audio_recording_worker():
    """Worker thread for audio recording."""
    global audio_frames, audio_stream, pyaudio_instance, audio_thread_running, FORMAT
    
    pyaudio_instance = pyaudio.PyAudio()
    
    audio_thread_running = True
    
    try:
        audio_stream = pyaudio_instance.open(format=FORMAT,
                                           channels=CHANNELS,
                                           rate=RATE,
                                           input=True,
                                           frames_per_buffer=CHUNK)

        while audio_thread_running:
            data = audio_stream.read(CHUNK, exception_on_overflow=False)
            audio_frames.append(data)
    except Exception as e:
        print(f"Error in audio recording: {e}")
    finally:
        if audio_stream:
            audio_stream.stop_stream()
            audio_stream.close()
        
def motion_detection_worker(label_camera, label_detections, total_detections_label, status_label):
    """Worker thread for motion detection and UI updates."""
    global is_motion_detected, last_motion_time, last_alarm_sound_time, alarm_running, camera, camera_thread_running, motion_events, video_writer, recording_active, audio_thread_running, temp_video_filename, temp_audio_filename, timestamp

    camera = cv2.VideoCapture(0)
    if not camera.isOpened():
        print("Error: Could not open webcam.")
        return

    ret, frame1 = camera.read()
    if not ret:
        print("Error: Could not read a frame from the camera.")
        camera.release()
        return
    
    if not os.path.exists('detections'):
        os.makedirs('detections')
    
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    temp_video_filename = os.path.join('detections', f'temp_video_{timestamp}.avi')
    video_writer = cv2.VideoWriter(temp_video_filename, fourcc, 20.0, (frame1.shape[1], frame1.shape[0]))
    
    audio_thread = threading.Thread(target=audio_recording_worker)
    audio_thread.daemon = True
    audio_thread.start()

    recording_active = True
    gray_frame1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
    blurred_frame1 = cv2.GaussianBlur(gray_frame1, (21, 21), 0)
    
    total_detections = 0
    camera_thread_running = True
    
    while camera_thread_running:
        ret, frame2 = camera.read()
        if not ret:
            break

        is_motion_detected = False
        
        gray_frame2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)
        blurred_frame2 = cv2.GaussianBlur(gray_frame2, (21, 21), 0)

        frame_delta = cv2.absdiff(blurred_frame1, blurred_frame2)
        thresh = cv2.threshold(frame_delta, 25, 255, cv2.THRESH_BINARY)[1]
        thresh = cv2.dilate(thresh, None, iterations=2)
        contours, _ = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for contour in contours:
            if cv2.contourArea(contour) < MOTION_THRESHOLD_AREA:
                continue
            
            is_motion_detected = True
            last_motion_time = time.time()
            (x, y, w, h) = cv2.boundingRect(contour)
            cv2.rectangle(frame2, (x, y), (x + w, y + h), (0, 255, 0), 2)
        
        if is_motion_detected:
            if time.time() - last_alarm_sound_time > 3:
                total_detections += 1
                total_detections_label.config(text=str(total_detections))
                
                capture_time = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
                image_filename = f'motion_{capture_time}.jpg'
                cv2.imwrite(os.path.join('detections', image_filename), frame2)
                
                new_entry_text = f"Motion Detected! ({time.strftime('%H:%M:%S')})"
                label_detections.insert(0, new_entry_text)
                motion_events.insert(0, {'time': capture_time, 'file': image_filename})

                last_alarm_sound_time = time.time()
            
            if not alarm_running:
                alarm_thread = threading.Thread(target=play_alarm_thread)
                alarm_thread.daemon = True
                alarm_thread.start()
            
            status_label.config(text="Status: Motion Detected!", foreground=RED)
        else:
            status_label.config(text="Status: No Motion", foreground=GREEN)
            
        blurred_frame1 = blurred_frame2
        
        if recording_active and video_writer:
            video_writer.write(frame2)
            
        frame_rgb = cv2.cvtColor(frame2, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(frame_rgb)
        img.thumbnail((320, 240))
        imgtk = ImageTk.PhotoImage(image=img)
        label_camera.imgtk = imgtk
        label_camera.config(image=imgtk)
        root.update()

    if video_writer:
        video_writer.release()
    camera.release()
    cv2.destroyAllWindows()
    
    if audio_thread_running:
        
        audio_thread_running = False
        
        try:
            temp_audio_filename = os.path.join('detections', f'temp_audio_{timestamp}.wav')
            wf = wave.open(temp_audio_filename, 'wb')
            wf.setnchannels(CHANNELS)
            wf.setsampwidth(pyaudio_instance.get_sample_size(FORMAT))
            wf.setframerate(RATE)
            wf.writeframes(b''.join(audio_frames))
            wf.close()
            audio_frames.clear()

            # Merge audio and video
            final_video_filename = os.path.join('detections', f'final_video_{timestamp}.avi')
            merge_command = [
                'ffmpeg', '-y', '-i', temp_video_filename, '-i', temp_audio_filename, '-c:v', 'copy', '-c:a', 'aac', '-map', '0:v:0', '-map', '1:a:0', final_video_filename
            ]
            subprocess.run(merge_command, check=True, creationflags=subprocess.CREATE_NO_WINDOW)
            os.remove(temp_video_filename)
            os.remove(temp_audio_filename)

        except FileNotFoundError:
            messagebox.showerror("Error", "FFmpeg not found. Please install FFmpeg to merge video and audio.")
            print("FFmpeg not found. Please install FFmpeg to merge video and audio.")
        except Exception as e:
            messagebox.showerror("Error", f"Error merging video and audio: {e}")
            print(f"Error merging video and audio: {e}")
        finally:
            if pyaudio_instance:
                pyaudio_instance.terminate()

    camera_thread_running = False
    
def start_motion_detection(welcome_frame, active_frame, label_camera, label_detections, total_detections_label, status_label):
    """Hides the welcome screen and starts the detection process."""
    global root
    welcome_frame.pack_forget()
    active_frame.pack(fill=tk.BOTH, expand=True)

    detection_thread = threading.Thread(target=motion_detection_worker, args=(label_camera, label_detections, total_detections_label, status_label))
    detection_thread.daemon = True
    detection_thread.start()

def stop_motion_detection(active_frame, welcome_frame):
    """Stops the motion detection and returns to the welcome screen."""
    global camera_thread_running, is_motion_detected, last_motion_time, alarm_running, recording_active
    camera_thread_running = False
    is_motion_detected = False
    last_motion_time = 0
    alarm_running = False
    recording_active = False
    active_frame.pack_forget()
    welcome_frame.pack(fill=tk.BOTH, expand=True)

def save_report():
    """Generates and saves a report of motion events."""
    if not motion_events:
        messagebox.showinfo("No Data", "No motion events to report.")
        return

    report_content = "Motion Detection Report\n"
    report_content += f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
    report_content += "----------------------------------------\n"
    
    for event in motion_events:
        report_content += f"Time: {event['time']}\n"
        report_content += f"Image File: {event['file']}\n"
        report_content += "----------------------------------------\n"

    try:
        file_path = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Text files", "*.txt")], initialfile="motion_report.txt")
        if file_path:
            with open(file_path, "w") as f:
                f.write(report_content)
            messagebox.showinfo("Success", f"Report saved successfully to {file_path}")
    except Exception as e:
        messagebox.showerror("Error", f"Failed to save report: {e}")
    
def create_main_window():
    """Creates the main application window."""
    global root
    root = tk.Tk()
    root.title("MotionGuard AI")
    root.geometry("800x600")
    root.configure(bg=BACKGROUND_COLOR)
    root.resizable(True, True)

    def on_hover_in(event):
        event.widget.configure(bg='#3a4856')

    def on_hover_out(event):
        event.widget.configure(bg=CARD_COLOR)
        
    welcome_frame = tk.Frame(root, bg=CONTAINER_COLOR, padx=40, pady=40)
    welcome_frame.pack(expand=True, padx=20, pady=20, fill=tk.BOTH)

    tk.Label(welcome_frame, text="MotionGuard AI", font=("Arial", 28, "bold"), bg=CONTAINER_COLOR, fg='white').pack(pady=(0, 5))
    tk.Label(welcome_frame, text="Advanced Motion Detection System", font=("Arial", 20, "bold"), bg=CONTAINER_COLOR, fg=NEON_BLUE).pack(pady=(0, 20))
    tk.Label(welcome_frame, text="Experience cutting-edge motion detection technology powered by AI.", font=("Arial", 12), bg=CONTAINER_COLOR, fg='#c5c6c7').pack(pady=(0, 30))

    start_button = tk.Button(welcome_frame, text="Start Motion Detection", font=("Arial", 14, "bold"), bg=NEON_BLUE, fg=BACKGROUND_COLOR, relief="flat", padx=20, pady=10, activebackground=NEON_BLUE, activeforeground=BACKGROUND_COLOR)
    start_button.pack(pady=(0, 30))

    features_frame = tk.Frame(welcome_frame, bg=CONTAINER_COLOR)
    features_frame.pack(pady=(0, 20))

    def create_feature_card(parent, icon, title, description):
        card = tk.Frame(parent, bg=CARD_COLOR, padx=20, pady=20)
        card.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.BOTH, expand=True)
        card.bind("<Enter>", on_hover_in)
        card.bind("<Leave>", on_hover_out)
        
        tk.Label(card, text=icon, font=("Arial", 24), bg=CARD_COLOR, fg=NEON_BLUE).pack(anchor='w')
        tk.Label(card, text=title, font=("Arial", 14, "bold"), bg=CARD_COLOR, fg='white').pack(anchor='w', pady=(10, 5))
        tk.Label(card, text=description, font=("Arial", 10), bg=CARD_COLOR, fg='#c5c6c7', wraplength=150, justify='left').pack(anchor='w')
        
        for widget in card.winfo_children():
            widget.bind("<Enter>", on_hover_in)
            widget.bind("<Leave>", on_hover_out)

    create_feature_card(features_frame, "👁️", "Real-time Detection", "Advanced algorithms detect motion instantly with high precision.")
    create_feature_card(features_frame, "🛡️", "Security Focused", "Built with security and privacy as top priorities.")
    create_feature_card(features_frame, "⚡", "Lightning Fast", "Optimized performance for real-time processing.")
    create_feature_card(features_frame, "🤖", "AI Powered", "Machine learning algorithms for accurate detection.")
    
    active_frame = tk.Frame(root, bg=CONTAINER_COLOR)
    
    title_frame = tk.Frame(active_frame, bg=CONTAINER_COLOR)
    title_frame.pack(fill=tk.X, pady=(10, 0))
    
    back_button = tk.Button(title_frame, text="< Back", command=lambda: stop_motion_detection(active_frame, welcome_frame), bg=CONTAINER_COLOR, fg=NEON_BLUE, relief="flat")
    back_button.pack(side=tk.LEFT, padx=(10, 0))
    tk.Label(title_frame, text="Motion Detection Active", font=("Arial", 20, "bold"), bg=CONTAINER_COLOR, fg=NEON_BLUE).pack(side=tk.LEFT, expand=True, padx=20)
    
    stop_button = tk.Button(title_frame, text="Stop Monitoring", command=lambda: stop_motion_detection(active_frame, welcome_frame), bg=RED, fg='white', relief="flat")
    stop_button.pack(side=tk.RIGHT, padx=(0, 10))

    camera_frame = tk.Frame(active_frame, bg=CARD_COLOR, padx=10, pady=10)
    camera_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
    
    label_camera = tk.Label(camera_frame, bg=CARD_COLOR)
    label_camera.pack(fill=tk.BOTH, expand=True)

    # Detection stats
    stats_frame_active = tk.Frame(active_frame, bg=CONTAINER_COLOR)
    stats_frame_active.pack(fill=tk.X, padx=20, pady=(0, 10))
    
    total_detections_label = tk.Label(stats_frame_active, text="0", font=("Arial", 24, "bold"), bg=CONTAINER_COLOR, fg=NEON_BLUE)
    total_detections_label.pack(side=tk.LEFT, padx=(0, 10))
    
    status_label = tk.Label(stats_frame_active, text="Status: No Motion", font=("Arial", 12), bg=CONTAINER_COLOR, fg=GREEN)
    status_label.pack(side=tk.LEFT, padx=(0, 10))

    detections_frame = tk.Frame(active_frame, bg=CARD_COLOR, padx=10, pady=10)
    detections_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=(0, 20))
    tk.Label(detections_frame, text="Recent Detections", font=("Arial", 16, "bold"), bg=CARD_COLOR, fg=NEON_BLUE).pack(anchor='w')
    
    label_detections = tk.Listbox(detections_frame, bg=CARD_COLOR, fg='#c5c6c7', selectbackground=NEON_BLUE, selectforeground=BACKGROUND_COLOR, relief="flat", height=5)
    label_detections.pack(fill=tk.BOTH, expand=True)

    save_button = tk.Button(active_frame, text="Save Report", command=save_report, bg=NEON_BLUE, fg=BACKGROUND_COLOR, relief="flat")
    save_button.pack(pady=(0, 10), fill=tk.X, padx=20)
    
    start_button.config(command=lambda: start_motion_detection(welcome_frame, active_frame, label_camera, label_detections, total_detections_label, status_label))
    
    root.mainloop()

if __name__ == "__main__":
    create_main_window()
