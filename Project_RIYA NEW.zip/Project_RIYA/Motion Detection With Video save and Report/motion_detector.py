import cv2
import numpy as np
import threading
import sys
import os
import time

ALARM_MESSAGE = "Motion Detected!"
MOTION_THRESHOLD_AREA = 5000
ALARM_SOUND_DURATION = 0.5
ALARM_SOUND_FREQUENCY = 1000

# Global flag to control the alarm loop
alarm_on = False
alarm_lock = threading.Lock()

def _alarm_loop_worker():
    while True:
        with alarm_lock:
            if alarm_on:
                if sys.platform == "win32":
                    try:
                        import winsound
                        winsound.Beep(ALARM_SOUND_FREQUENCY, int(ALARM_SOUND_DURATION * 1000))
                    except Exception as e:
                        print(f"Could not play sound on Windows: {e}")
                else:
                    try:
                        if sys.platform == "darwin":
                            os.system('say "Motion Detected"')
                        else:
                            os.system('echo -e "\a"')
                    except Exception as e:
                        print(f"Could not play system sound: {e}")
        time.sleep(0.1)

def motion_detection_system():
    global alarm_on
    camera = cv2.VideoCapture(0)
    
    if not camera.isOpened():
        print("Error: Could not open webcam.")
        return

    print("Motion detection system is starting. Press 'q' to quit.")

    ret, frame1 = camera.read()
    if not ret:
        print("Error: Could not read a frame from the camera.")
        return

    gray_frame1 = cv2.cvtColor(frame1, cv2.COLOR_BGR2GRAY)
    blurred_frame1 = cv2.GaussianBlur(gray_frame1, (21, 21), 0)
    
    # Start the continuous alarm thread
    alarm_thread = threading.Thread(target=_alarm_loop_worker, daemon=True)
    alarm_thread.start()

    while True:
        ret, frame2 = camera.read()
        if not ret:
            break

        gray_frame2 = cv2.cvtColor(frame2, cv2.COLOR_BGR2GRAY)
        blurred_frame2 = cv2.GaussianBlur(gray_frame2, (21, 21), 0)

        frame_delta = cv2.absdiff(blurred_frame1, blurred_frame2)

        thresh = cv2.threshold(frame_delta, 25, 255, cv2.THRESH_BINARY)[1]

        thresh = cv2.dilate(thresh, None, iterations=2)

        contours, _ = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        motion_detected = False

        for contour in contours:
            if cv2.contourArea(contour) < MOTION_THRESHOLD_AREA:
                continue

            motion_detected = True

            (x, y, w, h) = cv2.boundingRect(contour)
            
            cv2.rectangle(frame2, (x, y), (x + w, y + h), (0, 255, 0), 2)
            
        with alarm_lock:
            if motion_detected:
                if not alarm_on:
                    print(ALARM_MESSAGE)
                alarm_on = True
            else:
                alarm_on = False

        status_text = "Status: Motion Detected!" if motion_detected else "Status: No Motion"
        cv2.putText(frame2, status_text, (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)
        
        cv2.imshow("Motion Detection System", frame2)
        cv2.imshow("Thresholded Image", thresh)

        blurred_frame1 = blurred_frame2

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    camera.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    motion_detection_system()