import winsound
try:
    winsound.PlaySound("alarm.wav", winsound.SND_FILENAME)
    print("Sound played successfully!")
except Exception as e:
    print(f"Error: {e}")